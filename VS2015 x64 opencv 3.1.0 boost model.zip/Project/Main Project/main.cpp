#include "stdafx.h"
#include "opencv2/imgproc/imgproc.hpp";
#include "opencv2/highgui/highgui.hpp";

using namespace cv;
using namespace std;
int _tmain(int argc, _TCHAR* argv[])
{
	Mat img = imread("test.jpg");
	imshow("logo", img);
	waitKey();
	system("pause");
	return 0;
}